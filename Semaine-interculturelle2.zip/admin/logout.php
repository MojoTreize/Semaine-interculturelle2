<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_logout();
set_flash('success', 'Abgemeldet.');
redirect('admin/login.php');
