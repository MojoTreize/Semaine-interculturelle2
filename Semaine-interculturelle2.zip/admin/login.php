<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

if (admin_is_logged_in()) {
    redirect('admin/index.php');
}

if (is_post()) {
    verify_csrf_or_fail();
    remember_old_input($_POST);

    if (!honeypot_passed()) {
        set_flash('error', t('validation.honeypot'));
        redirect('admin/login.php');
    }

    $email = strtolower(post_string('email'));
    $password = post_string('password');

    if (admin_attempt_login($pdo, $email, $password)) {
        clear_old_input();
        set_flash('success', 'Login erfolgreich.');
        redirect('admin/index.php');
    }

    set_flash('error', 'Ungueltige Zugangsdaten.');
    redirect('admin/login.php');
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(t('admin.login_title')) ?></title>
    <link rel="stylesheet" href="<?= e(base_url('assets/css/admin.css')) ?>">
</head>
<body>
<main style="max-width:420px;margin:8vh auto;padding:1rem;">
    <article class="card">
        <h1><?= e(t('admin.login_title')) ?></h1>

        <?php if ($flash): ?>
            <div class="alert alert-<?= e((string) ($flash['type'] ?? 'error')) ?>">
                <?= e((string) ($flash['message'] ?? '')) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="<?= e(admin_url('login.php')) ?>">
            <?= csrf_field() ?>
            <?= honeypot_field_html() ?>

            <div class="form-group">
                <label for="email"><?= e(t('admin.email')) ?></label>
                <input id="email" type="email" name="email" value="<?= e(old('email')) ?>" required>
            </div>

            <div class="form-group">
                <label for="password"><?= e(t('admin.password')) ?></label>
                <input id="password" type="password" name="password" required>
            </div>

            <button type="submit" class="btn"><?= e(t('buttons.login')) ?></button>
        </form>
    </article>
</main>
</body>
</html>
