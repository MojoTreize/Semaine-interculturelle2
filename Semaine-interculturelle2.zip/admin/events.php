<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_require_login();
$pdo = admin_db_or_fail($pdo);

$itemTypes = [
    'conference' => t('program.conference'),
    'panel' => t('program.panel'),
    'exhibition' => t('program.exhibition'),
    'networking' => t('program.networking'),
    'ceremony' => t('program.ceremony'),
    'workshop' => t('program.workshop'),
];

$normalizeTime = static function (string $value): ?string {
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    if (preg_match('/^\d{2}:\d{2}$/', $value) === 1) {
        return $value . ':00';
    }
    if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $value) === 1) {
        return $value;
    }

    return null;
};

if (is_post()) {
    verify_csrf_or_fail();

    $action = post_string('action');
    $id = (int) post_string('id');

    if ($action === 'delete') {
        if ($id > 0) {
            try {
                $stmt = $pdo->prepare('DELETE FROM program_items WHERE id = :id');
                $stmt->execute(['id' => $id]);
                set_flash('success', 'Event geloescht.');
            } catch (Throwable) {
                set_flash('error', 'Event konnte nicht geloescht werden.');
            }
        }

        redirect('admin/events.php');
    }

    $eventDate = post_string('event_date');
    $startTime = $normalizeTime(post_string('start_time'));
    $endTime = $normalizeTime(post_string('end_time'));
    $titleFr = post_string('title_fr');
    $titleDe = post_string('title_de');
    $descriptionFr = post_string('description_fr');
    $descriptionDe = post_string('description_de');
    $location = post_string('location');
    $itemType = post_string('item_type');
    $displayOrder = max(0, (int) post_string('display_order'));
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    $isValidDate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $eventDate) === 1;
    if (!$isValidDate || $titleFr === '' || $titleDe === '' || !array_key_exists($itemType, $itemTypes)) {
        set_flash('error', 'Bitte Pflichtfelder korrekt ausfuellen.');
        $target = $action === 'update' && $id > 0 ? 'admin/events.php?edit=' . $id : 'admin/events.php';
        redirect($target);
    }

    if ($startTime === null && post_string('start_time') !== '') {
        set_flash('error', 'Startzeit ist ungueltig.');
        $target = $action === 'update' && $id > 0 ? 'admin/events.php?edit=' . $id : 'admin/events.php';
        redirect($target);
    }

    if ($endTime === null && post_string('end_time') !== '') {
        set_flash('error', 'Endzeit ist ungueltig.');
        $target = $action === 'update' && $id > 0 ? 'admin/events.php?edit=' . $id : 'admin/events.php';
        redirect($target);
    }

    try {
        if ($action === 'update' && $id > 0) {
            $stmt = $pdo->prepare(
                'UPDATE program_items
                 SET event_date = :event_date,
                     start_time = :start_time,
                     end_time = :end_time,
                     title_fr = :title_fr,
                     title_de = :title_de,
                     description_fr = :description_fr,
                     description_de = :description_de,
                     location = :location,
                     item_type = :item_type,
                     display_order = :display_order,
                     is_active = :is_active
                 WHERE id = :id'
            );
            $stmt->execute([
                'event_date' => $eventDate,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'title_fr' => $titleFr,
                'title_de' => $titleDe,
                'description_fr' => $descriptionFr !== '' ? $descriptionFr : null,
                'description_de' => $descriptionDe !== '' ? $descriptionDe : null,
                'location' => $location !== '' ? $location : null,
                'item_type' => $itemType,
                'display_order' => $displayOrder,
                'is_active' => $isActive,
                'id' => $id,
            ]);
            set_flash('success', 'Event aktualisiert.');
        } else {
            $stmt = $pdo->prepare(
                'INSERT INTO program_items
                    (event_date, start_time, end_time, title_fr, title_de, description_fr, description_de, location, item_type, display_order, is_active)
                 VALUES
                    (:event_date, :start_time, :end_time, :title_fr, :title_de, :description_fr, :description_de, :location, :item_type, :display_order, :is_active)'
            );
            $stmt->execute([
                'event_date' => $eventDate,
                'start_time' => $startTime,
                'end_time' => $endTime,
                'title_fr' => $titleFr,
                'title_de' => $titleDe,
                'description_fr' => $descriptionFr !== '' ? $descriptionFr : null,
                'description_de' => $descriptionDe !== '' ? $descriptionDe : null,
                'location' => $location !== '' ? $location : null,
                'item_type' => $itemType,
                'display_order' => $displayOrder,
                'is_active' => $isActive,
            ]);
            set_flash('success', 'Event erstellt.');
        }
    } catch (Throwable) {
        set_flash('error', 'Event konnte nicht gespeichert werden.');
    }

    redirect('admin/events.php');
}

$editId = (int) ($_GET['edit'] ?? 0);
$editingItem = null;

if ($editId > 0) {
    try {
        $stmt = $pdo->prepare('SELECT * FROM program_items WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $editId]);
        $editingItem = $stmt->fetch() ?: null;
    } catch (Throwable) {
        $editingItem = null;
    }
}

$events = [];
try {
    $events = $pdo->query(
        'SELECT id, event_date, start_time, end_time, title_fr, title_de, item_type, location, display_order, is_active
         FROM program_items
         ORDER BY event_date ASC, start_time ASC, display_order ASC, id ASC'
    )->fetchAll();
} catch (Throwable) {
    $events = [];
}

$formAction = $editingItem ? 'update' : 'create';

admin_render_start('Events', 'events');
?>
<section class="card">
    <h2><?= $editingItem ? 'Event bearbeiten' : 'Neues Event' ?></h2>
    <form method="post" action="<?= e(admin_url('events.php')) ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="<?= e($formAction) ?>">
        <input type="hidden" name="id" value="<?= e((string) ($editingItem['id'] ?? 0)) ?>">

        <div class="row">
            <div>
                <label for="event_date">Datum *</label>
                <input id="event_date" type="date" name="event_date" value="<?= e((string) ($editingItem['event_date'] ?? '')) ?>" required>
            </div>
            <div>
                <label for="item_type">Typ *</label>
                <select id="item_type" name="item_type" required>
                    <?php foreach ($itemTypes as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= (string) ($editingItem['item_type'] ?? '') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row">
            <div>
                <label for="start_time">Startzeit</label>
                <input id="start_time" type="time" name="start_time" value="<?= e(substr((string) ($editingItem['start_time'] ?? ''), 0, 5)) ?>">
            </div>
            <div>
                <label for="end_time">Endzeit</label>
                <input id="end_time" type="time" name="end_time" value="<?= e(substr((string) ($editingItem['end_time'] ?? ''), 0, 5)) ?>">
            </div>
        </div>

        <div class="row">
            <div>
                <label for="title_fr">Titel FR *</label>
                <input id="title_fr" type="text" name="title_fr" value="<?= e((string) ($editingItem['title_fr'] ?? '')) ?>" required>
            </div>
            <div>
                <label for="title_de">Titel DE *</label>
                <input id="title_de" type="text" name="title_de" value="<?= e((string) ($editingItem['title_de'] ?? '')) ?>" required>
            </div>
        </div>

        <div class="row">
            <div>
                <label for="description_fr">Beschreibung FR</label>
                <textarea id="description_fr" name="description_fr"><?= e((string) ($editingItem['description_fr'] ?? '')) ?></textarea>
            </div>
            <div>
                <label for="description_de">Beschreibung DE</label>
                <textarea id="description_de" name="description_de"><?= e((string) ($editingItem['description_de'] ?? '')) ?></textarea>
            </div>
        </div>

        <div class="row">
            <div>
                <label for="location">Ort</label>
                <input id="location" type="text" name="location" value="<?= e((string) ($editingItem['location'] ?? '')) ?>">
            </div>
            <div>
                <label for="display_order">Sortierung</label>
                <input id="display_order" type="number" min="0" name="display_order" value="<?= e((string) ($editingItem['display_order'] ?? '0')) ?>">
            </div>
        </div>

        <div style="margin:0.8rem 0;">
            <label>
                <input type="checkbox" name="is_active" value="1" <?= ((int) ($editingItem['is_active'] ?? 1) === 1) ? 'checked' : '' ?>>
                Aktiv auf der Website sichtbar
            </label>
        </div>

        <button type="submit" class="btn"><?= $editingItem ? 'Event speichern' : 'Event anlegen' ?></button>
        <?php if ($editingItem): ?>
            <a class="btn btn-muted" href="<?= e(admin_url('events.php')) ?>">Abbrechen</a>
        <?php endif; ?>
    </form>
</section>

<section class="card">
    <h2>Alle Events</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Datum</th>
                <th>Zeit</th>
                <th>Titel (DE)</th>
                <th>Typ</th>
                <th>Aktiv</th>
                <th>Aktion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($events as $event): ?>
                <tr>
                    <td><?= e((string) ($event['id'] ?? '')) ?></td>
                    <td><?= e((string) ($event['event_date'] ?? '')) ?></td>
                    <td><?= e(substr((string) ($event['start_time'] ?? ''), 0, 5)) ?> - <?= e(substr((string) ($event['end_time'] ?? ''), 0, 5)) ?></td>
                    <td><?= e((string) ($event['title_de'] ?? '')) ?></td>
                    <td><?= e((string) ($event['item_type'] ?? '')) ?></td>
                    <td><?= ((int) ($event['is_active'] ?? 0) === 1) ? 'ja' : 'nein' ?></td>
                    <td>
                        <a href="<?= e(admin_url('events.php?edit=' . (int) ($event['id'] ?? 0))) ?>">Bearbeiten</a>
                        <form method="post" action="<?= e(admin_url('events.php')) ?>" style="display:inline-block;margin-left:0.5rem;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= e((string) ($event['id'] ?? 0)) ?>">
                            <button type="submit" class="btn btn-muted" onclick="return confirm('Event wirklich loeschen?');">Loeschen</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($events)): ?>
                <tr>
                    <td colspan="7">Keine Events vorhanden.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php admin_render_end(); ?>
