<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

// Dev helper: auto-create an admin session to test all admin pages without login form.
$_SESSION['admin'] = [
    'id' => 0,
    'full_name' => 'Test Admin (No Login)',
    'email' => 'test-admin@local',
    'role' => 'super_admin',
];

$pdo = admin_db_or_fail($pdo);

$counts = [
    'events' => 0,
    'registrations' => 0,
    'requests' => 0,
    'donations' => 0,
    'paid_total' => 0.0,
];

try {
    $counts['events'] = (int) $pdo->query('SELECT COUNT(*) FROM program_items')->fetchColumn();
    $counts['registrations'] = (int) $pdo->query('SELECT COUNT(*) FROM registrations')->fetchColumn();
    $counts['requests'] = (int) $pdo->query('SELECT (SELECT COUNT(*) FROM sponsor_requests) + (SELECT COUNT(*) FROM contact_messages)')->fetchColumn();
    $counts['donations'] = (int) $pdo->query('SELECT COUNT(*) FROM donations')->fetchColumn();
    $counts['paid_total'] = (float) $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM donations WHERE payment_status = 'paid'")->fetchColumn();
} catch (Throwable) {
    // Keep page usable even when one query fails.
}

admin_render_start('Test Admin', 'dashboard');
?>
<section class="card">
    <h2>Testmodus aktiv (ohne Login)</h2>
    <p>
        Diese Seite setzt automatisch eine Admin-Session.
        Du kannst damit alle Admin-Seiten direkt testen.
    </p>
    <p>
        <strong>Wichtig:</strong> Diese Datei nur fuer Tests nutzen und vor Live-Betrieb entfernen.
    </p>
</section>

<section class="stats">
    <article class="stat">
        <span>Events</span>
        <strong><?= e((string) $counts['events']) ?></strong>
    </article>
    <article class="stat">
        <span>Anmeldungen</span>
        <strong><?= e((string) $counts['registrations']) ?></strong>
    </article>
    <article class="stat">
        <span>Anfragen</span>
        <strong><?= e((string) $counts['requests']) ?></strong>
    </article>
    <article class="stat">
        <span>Spenden</span>
        <strong><?= e((string) $counts['donations']) ?></strong>
    </article>
    <article class="stat">
        <span>Spenden bezahlt</span>
        <strong><?= e(format_amount((float) $counts['paid_total'])) ?></strong>
    </article>
</section>

<section class="card">
    <h2>Schnellzugriff</h2>
    <p><a class="btn" href="<?= e(admin_url('index.php')) ?>">Dashboard</a></p>
    <p><a class="btn" href="<?= e(admin_url('events.php')) ?>">Events erstellen/bearbeiten</a></p>
    <p><a class="btn" href="<?= e(admin_url('registrations.php')) ?>">Anmeldungen</a></p>
    <p><a class="btn" href="<?= e(admin_url('requests.php')) ?>">Anfragen</a></p>
    <p><a class="btn" href="<?= e(admin_url('donations.php')) ?>">Spenden</a></p>
</section>

<section class="card">
    <h2>Public-Seiten zum Gegencheck</h2>
    <p><a href="<?= e(base_url('index.php')) ?>" target="_blank" rel="noopener">Startseite</a></p>
    <p><a href="<?= e(base_url('program.php')) ?>" target="_blank" rel="noopener">Programmseite (zeigt Events aus DB)</a></p>
</section>

<?php admin_render_end(); ?>
