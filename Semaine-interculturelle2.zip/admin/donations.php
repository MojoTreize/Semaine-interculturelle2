<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_require_login();
$pdo = admin_db_or_fail($pdo);

$allowedStatuses = ['pending', 'paid', 'failed', 'canceled'];
$selectedStatus = strtolower(trim((string) ($_GET['status'] ?? '')));
if (!in_array($selectedStatus, $allowedStatuses, true)) {
    $selectedStatus = '';
}

if (is_post()) {
    verify_csrf_or_fail();

    $action = post_string('action');
    $id = (int) post_string('id');
    $status = post_string('status');

    if ($action === 'update_status' && $id > 0 && in_array($status, $allowedStatuses, true)) {
        try {
            $sql = 'UPDATE donations SET payment_status = :payment_status';
            if ($status === 'paid') {
                $sql .= ', paid_at = ' . db_now_expression($pdo);
            }
            $sql .= ' WHERE id = :id';

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'payment_status' => $status,
                'id' => $id,
            ]);
            set_flash('success', 'Status aktualisiert.');
        } catch (Throwable) {
            set_flash('error', 'Status konnte nicht aktualisiert werden.');
        }
    }

    redirect('admin/donations.php' . ($selectedStatus !== '' ? '?status=' . urlencode($selectedStatus) : ''));
}

$whereSql = '';
$params = [];
if ($selectedStatus !== '') {
    $whereSql = 'WHERE payment_status = :payment_status';
    $params['payment_status'] = $selectedStatus;
}

$rows = [];
try {
    $sql = 'SELECT id, donor_name, donor_email, amount, currency, motive, custom_motive, payment_method, payment_provider_id, payment_status, created_at, paid_at
            FROM donations ' . $whereSql . '
            ORDER BY created_at DESC
            LIMIT 300';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
} catch (Throwable) {
    set_flash('error', 'Spenden konnten nicht geladen werden.');
}

if (($_GET['export'] ?? '') === 'csv') {
    $csvRows = array_map(static function (array $row): array {
        return [
            (string) ($row['id'] ?? ''),
            (string) ($row['donor_name'] ?? ''),
            (string) ($row['donor_email'] ?? ''),
            (string) ($row['amount'] ?? ''),
            (string) ($row['currency'] ?? ''),
            (string) ($row['motive'] ?? ''),
            (string) ($row['custom_motive'] ?? ''),
            (string) ($row['payment_method'] ?? ''),
            (string) ($row['payment_provider_id'] ?? ''),
            (string) ($row['payment_status'] ?? ''),
            (string) ($row['created_at'] ?? ''),
            (string) ($row['paid_at'] ?? ''),
        ];
    }, $rows);

    output_csv_download(
        'donations.csv',
        ['ID', 'Donor Name', 'Donor Email', 'Amount', 'Currency', 'Motive', 'Custom Motive', 'Method', 'Provider ID', 'Status', 'Created At', 'Paid At'],
        $csvRows
    );
}

admin_render_start('Spenden', 'donations');
?>
<section class="card">
    <h2>Spenden</h2>
    <form method="get" action="<?= e(admin_url('donations.php')) ?>" style="margin-bottom:0.9rem;">
        <div class="row">
            <div>
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="">Alle</option>
                    <?php foreach ($allowedStatuses as $status): ?>
                        <option value="<?= e($status) ?>" <?= $selectedStatus === $status ? 'selected' : '' ?>><?= e($status) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="display:flex;align-items:flex-end;gap:0.6rem;">
                <button type="submit" class="btn"><?= e(t('admin.filter')) ?></button>
                <a class="btn btn-muted" href="<?= e(admin_url('donations.php?export=csv' . ($selectedStatus !== '' ? '&status=' . urlencode($selectedStatus) : ''))) ?>"><?= e(t('admin.export_csv')) ?></a>
            </div>
        </div>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Spender</th>
                <th>Betrag</th>
                <th>Zahlung</th>
                <th>Status</th>
                <th>Erstellt</th>
                <th>Aktion</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?= e((string) ($row['id'] ?? '')) ?></td>
                    <td><?= e((string) ($row['donor_name'] ?? ($row['donor_email'] ?? ''))) ?></td>
                    <td><?= e(format_amount((float) ($row['amount'] ?? 0), (string) ($row['currency'] ?? 'EUR'))) ?></td>
                    <td><?= e((string) ($row['payment_method'] ?? '')) ?></td>
                    <td><?= e((string) ($row['payment_status'] ?? '')) ?></td>
                    <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                    <td>
                        <form method="post" action="<?= e(admin_url('donations.php' . ($selectedStatus !== '' ? '?status=' . urlencode($selectedStatus) : ''))) ?>" style="display:flex;gap:0.4rem;align-items:center;">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="id" value="<?= e((string) ($row['id'] ?? 0)) ?>">
                            <select name="status">
                                <?php foreach ($allowedStatuses as $status): ?>
                                    <option value="<?= e($status) ?>" <?= (string) ($row['payment_status'] ?? '') === $status ? 'selected' : '' ?>><?= e($status) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn-muted">Setzen</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($rows)): ?>
                <tr>
                    <td colspan="7">Keine Datensaetze.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php admin_render_end(); ?>
