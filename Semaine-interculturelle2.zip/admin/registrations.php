<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_require_login();
$pdo = admin_db_or_fail($pdo);

$allowedTypes = ['participant', 'partner', 'speaker', 'sponsor'];
$selectedType = strtolower(trim((string) ($_GET['type'] ?? '')));
if (!in_array($selectedType, $allowedTypes, true)) {
    $selectedType = '';
}

$whereSql = '';
$params = [];
if ($selectedType !== '') {
    $whereSql = 'WHERE participation_type = :participation_type';
    $params['participation_type'] = $selectedType;
}

if (($_GET['export'] ?? '') === 'csv') {
    try {
        $sql = 'SELECT id, first_name, last_name, country, email, phone, organization, participation_type, gdpr_consent, language, ip_address, created_at
                FROM registrations ' . $whereSql . '
                ORDER BY created_at DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        output_csv_download(
            'registrations.csv',
            ['ID', 'First Name', 'Last Name', 'Country', 'Email', 'Phone', 'Organization', 'Participation', 'GDPR', 'Language', 'IP', 'Created At'],
            array_map(static function (array $row): array {
                return [
                    (string) ($row['id'] ?? ''),
                    (string) ($row['first_name'] ?? ''),
                    (string) ($row['last_name'] ?? ''),
                    (string) ($row['country'] ?? ''),
                    (string) ($row['email'] ?? ''),
                    (string) ($row['phone'] ?? ''),
                    (string) ($row['organization'] ?? ''),
                    (string) ($row['participation_type'] ?? ''),
                    ((int) ($row['gdpr_consent'] ?? 0) === 1) ? '1' : '0',
                    (string) ($row['language'] ?? ''),
                    (string) ($row['ip_address'] ?? ''),
                    (string) ($row['created_at'] ?? ''),
                ];
            }, $rows)
        );
    } catch (Throwable) {
        set_flash('error', 'CSV-Export fehlgeschlagen.');
        redirect('admin/registrations.php');
    }
}

$rows = [];
try {
    $sql = 'SELECT id, first_name, last_name, country, email, phone, organization, participation_type, gdpr_consent, language, created_at
            FROM registrations ' . $whereSql . '
            ORDER BY created_at DESC
            LIMIT 300';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
} catch (Throwable) {
    set_flash('error', 'Anmeldungen konnten nicht geladen werden.');
}

admin_render_start('Anmeldungen', 'registrations');
?>
<section class="card">
    <h2>Anmeldungen</h2>
    <form method="get" action="<?= e(admin_url('registrations.php')) ?>" style="margin-bottom:0.9rem;">
        <div class="row">
            <div>
                <label for="type">Teilnahmeart</label>
                <select id="type" name="type">
                    <option value="">Alle</option>
                    <?php foreach ($allowedTypes as $type): ?>
                        <option value="<?= e($type) ?>" <?= $selectedType === $type ? 'selected' : '' ?>><?= e($type) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div style="display:flex;align-items:flex-end;gap:0.6rem;">
                <button type="submit" class="btn"><?= e(t('admin.filter')) ?></button>
                <a class="btn btn-muted" href="<?= e(admin_url('registrations.php?export=csv' . ($selectedType !== '' ? '&type=' . urlencode($selectedType) : ''))) ?>"><?= e(t('admin.export_csv')) ?></a>
            </div>
        </div>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Land</th>
                <th>Telefon</th>
                <th>Typ</th>
                <th>DSGVO</th>
                <th>Datum</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?= e((string) ($row['id'] ?? '')) ?></td>
                    <td><?= e(trim((string) ($row['first_name'] ?? '') . ' ' . (string) ($row['last_name'] ?? ''))) ?></td>
                    <td><?= e((string) ($row['email'] ?? '')) ?></td>
                    <td><?= e((string) ($row['country'] ?? '')) ?></td>
                    <td><?= e((string) ($row['phone'] ?? '')) ?></td>
                    <td><?= e((string) ($row['participation_type'] ?? '')) ?></td>
                    <td><?= ((int) ($row['gdpr_consent'] ?? 0) === 1) ? 'ja' : 'nein' ?></td>
                    <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($rows)): ?>
                <tr>
                    <td colspan="8">Keine Datensaetze.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php admin_render_end(); ?>
