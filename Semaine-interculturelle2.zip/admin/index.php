<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_require_login();
$pdo = admin_db_or_fail($pdo);

$stats = [
    'registrations' => 0,
    'sponsor_requests' => 0,
    'contact_messages' => 0,
    'events_active' => 0,
    'donations_paid_count' => 0,
    'donations_paid_total' => 0.0,
    'visits_30d' => 0,
];

$topPages = [];
$recentRegistrations = [];
$recentRequests = [];
$recentDonations = [];

try {
    $stats['registrations'] = (int) $pdo->query('SELECT COUNT(*) FROM registrations')->fetchColumn();
    $stats['sponsor_requests'] = (int) $pdo->query('SELECT COUNT(*) FROM sponsor_requests')->fetchColumn();
    $stats['contact_messages'] = (int) $pdo->query('SELECT COUNT(*) FROM contact_messages')->fetchColumn();
    $stats['events_active'] = (int) $pdo->query('SELECT COUNT(*) FROM program_items WHERE is_active = 1')->fetchColumn();
    $stats['donations_paid_count'] = (int) $pdo->query("SELECT COUNT(*) FROM donations WHERE payment_status = 'paid'")->fetchColumn();
    $stats['donations_paid_total'] = (float) $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM donations WHERE payment_status = 'paid'")->fetchColumn();

    $since = (new DateTimeImmutable('-30 days', new DateTimeZone('UTC')))->format('Y-m-d H:i:s');
    $topPagesStmt = $pdo->prepare(
        'SELECT page_path, COUNT(*) AS total_views
         FROM page_views
         WHERE viewed_at >= :since
         GROUP BY page_path
         ORDER BY total_views DESC
         LIMIT 12'
    );
    $topPagesStmt->execute(['since' => $since]);
    $topPages = $topPagesStmt->fetchAll();

    $visitsStmt = $pdo->prepare('SELECT COUNT(*) FROM page_views WHERE viewed_at >= :since');
    $visitsStmt->execute(['since' => $since]);
    $stats['visits_30d'] = (int) $visitsStmt->fetchColumn();

    $recentRegistrations = $pdo->query(
        'SELECT first_name, last_name, email, participation_type, created_at
         FROM registrations
         ORDER BY created_at DESC
         LIMIT 8'
    )->fetchAll();

    $recentRequests = $pdo->query(
        "SELECT 'sponsor' AS request_type, organization_name AS display_name, email, created_at
         FROM sponsor_requests
         UNION ALL
         SELECT 'contact' AS request_type, full_name AS display_name, email, created_at
         FROM contact_messages
         ORDER BY created_at DESC
         LIMIT 8"
    )->fetchAll();

    $recentDonations = $pdo->query(
        'SELECT donor_name, donor_email, amount, payment_method, payment_status, created_at
         FROM donations
         ORDER BY created_at DESC
         LIMIT 8'
    )->fetchAll();
} catch (Throwable) {
    set_flash('error', 'Dashboard konnte nicht vollstaendig geladen werden.');
}

admin_render_start('Dashboard', 'dashboard');
?>
<section class="stats">
    <article class="stat">
        <span>Anmeldungen</span>
        <strong><?= e((string) $stats['registrations']) ?></strong>
    </article>
    <article class="stat">
        <span>Sponsoring-Anfragen</span>
        <strong><?= e((string) $stats['sponsor_requests']) ?></strong>
    </article>
    <article class="stat">
        <span>Kontaktanfragen</span>
        <strong><?= e((string) $stats['contact_messages']) ?></strong>
    </article>
    <article class="stat">
        <span>Aktive Events</span>
        <strong><?= e((string) $stats['events_active']) ?></strong>
    </article>
    <article class="stat">
        <span>Spenden bezahlt</span>
        <strong><?= e((string) $stats['donations_paid_count']) ?></strong>
    </article>
    <article class="stat">
        <span>Spendenumsatz</span>
        <strong><?= e(format_amount((float) $stats['donations_paid_total'])) ?></strong>
    </article>
    <article class="stat">
        <span>Besuche (30 Tage)</span>
        <strong><?= e((string) $stats['visits_30d']) ?></strong>
    </article>
</section>

<section class="card">
    <h2>Top Seiten (30 Tage)</h2>
    <table>
        <thead>
            <tr>
                <th>Seite</th>
                <th>Aufrufe</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($topPages as $row): ?>
                <tr>
                    <td><?= e((string) ($row['page_path'] ?? '')) ?></td>
                    <td><?= e((string) ($row['total_views'] ?? 0)) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($topPages)): ?>
                <tr>
                    <td colspan="2">Keine Analytics-Daten vorhanden.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<section class="row">
    <article class="card">
        <h2>Letzte Anmeldungen</h2>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Typ</th>
                    <th>Datum</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentRegistrations as $row): ?>
                    <tr>
                        <td><?= e(trim((string) ($row['first_name'] ?? '') . ' ' . (string) ($row['last_name'] ?? ''))) ?></td>
                        <td><?= e((string) ($row['email'] ?? '')) ?></td>
                        <td><?= e((string) ($row['participation_type'] ?? '')) ?></td>
                        <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recentRegistrations)): ?>
                    <tr>
                        <td colspan="4">Keine Datensaetze.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </article>

    <article class="card">
        <h2>Letzte Anfragen</h2>
        <table>
            <thead>
                <tr>
                    <th>Typ</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Datum</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentRequests as $row): ?>
                    <tr>
                        <td><?= e((string) ($row['request_type'] ?? '')) ?></td>
                        <td><?= e((string) ($row['display_name'] ?? '')) ?></td>
                        <td><?= e((string) ($row['email'] ?? '')) ?></td>
                        <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recentRequests)): ?>
                    <tr>
                        <td colspan="4">Keine Datensaetze.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </article>
</section>

<section class="card">
    <h2>Letzte Spenden</h2>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Betrag</th>
                <th>Methode</th>
                <th>Status</th>
                <th>Datum</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($recentDonations as $row): ?>
                <tr>
                    <td><?= e((string) ($row['donor_name'] ?? '')) ?></td>
                    <td><?= e((string) ($row['donor_email'] ?? '')) ?></td>
                    <td><?= e(format_amount((float) ($row['amount'] ?? 0))) ?></td>
                    <td><?= e((string) ($row['payment_method'] ?? '')) ?></td>
                    <td><?= e((string) ($row['payment_status'] ?? '')) ?></td>
                    <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($recentDonations)): ?>
                <tr>
                    <td colspan="6">Keine Datensaetze.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php admin_render_end(); ?>
