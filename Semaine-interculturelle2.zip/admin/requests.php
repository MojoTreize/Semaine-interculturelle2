<?php

declare(strict_types=1);

require __DIR__ . '/_common.php';

admin_require_login();
$pdo = admin_db_or_fail($pdo);

$type = strtolower(trim((string) ($_GET['type'] ?? 'all')));
if (!in_array($type, ['all', 'sponsor', 'contact'], true)) {
    $type = 'all';
}

$rows = [];

try {
    if ($type === 'sponsor') {
        $rows = $pdo->query(
            "SELECT id, 'sponsor' AS request_type, organization_name AS display_name, contact_person, email, phone, website, sponsorship_level, message, created_at
             FROM sponsor_requests
             ORDER BY created_at DESC
             LIMIT 300"
        )->fetchAll();
    } elseif ($type === 'contact') {
        $rows = $pdo->query(
            "SELECT id, 'contact' AS request_type, full_name AS display_name, NULL AS contact_person, email, NULL AS phone, NULL AS website, subject AS sponsorship_level, message, created_at
             FROM contact_messages
             ORDER BY created_at DESC
             LIMIT 300"
        )->fetchAll();
    } else {
        $rows = $pdo->query(
            "SELECT id, request_type, display_name, contact_person, email, phone, website, meta_field, message, created_at
             FROM (
                 SELECT id, 'sponsor' AS request_type, organization_name AS display_name, contact_person, email, phone, website, sponsorship_level AS meta_field, message, created_at
                 FROM sponsor_requests
                 UNION ALL
                 SELECT id, 'contact' AS request_type, full_name AS display_name, NULL AS contact_person, email, NULL AS phone, NULL AS website, subject AS meta_field, message, created_at
                 FROM contact_messages
             ) merged
             ORDER BY created_at DESC
             LIMIT 300"
        )->fetchAll();
    }
} catch (Throwable) {
    set_flash('error', 'Anfragen konnten nicht geladen werden.');
}

if (($_GET['export'] ?? '') === 'csv') {
    $csvRows = array_map(static function (array $row): array {
        $meta = $row['meta_field'] ?? $row['sponsorship_level'] ?? '';
        return [
            (string) ($row['request_type'] ?? ''),
            (string) ($row['display_name'] ?? ''),
            (string) ($row['contact_person'] ?? ''),
            (string) ($row['email'] ?? ''),
            (string) ($row['phone'] ?? ''),
            (string) ($row['website'] ?? ''),
            (string) $meta,
            (string) ($row['message'] ?? ''),
            (string) ($row['created_at'] ?? ''),
        ];
    }, $rows);

    output_csv_download(
        'requests.csv',
        ['Type', 'Name', 'Contact Person', 'Email', 'Phone', 'Website', 'Meta', 'Message', 'Created At'],
        $csvRows
    );
}

admin_render_start('Anfragen', 'requests');
?>
<section class="card">
    <h2>Anfragen</h2>
    <form method="get" action="<?= e(admin_url('requests.php')) ?>" style="margin-bottom:0.9rem;">
        <div class="row">
            <div>
                <label for="type">Typ</label>
                <select id="type" name="type">
                    <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>Alle</option>
                    <option value="sponsor" <?= $type === 'sponsor' ? 'selected' : '' ?>>Sponsoring</option>
                    <option value="contact" <?= $type === 'contact' ? 'selected' : '' ?>>Kontakt</option>
                </select>
            </div>
            <div style="display:flex;align-items:flex-end;gap:0.6rem;">
                <button type="submit" class="btn"><?= e(t('admin.filter')) ?></button>
                <a class="btn btn-muted" href="<?= e(admin_url('requests.php?type=' . urlencode($type) . '&export=csv')) ?>"><?= e(t('admin.export_csv')) ?></a>
            </div>
        </div>
    </form>

    <table>
        <thead>
            <tr>
                <th>Typ</th>
                <th>Name</th>
                <th>Kontakt</th>
                <th>Email</th>
                <th>Meta</th>
                <th>Nachricht</th>
                <th>Datum</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <?php $meta = (string) ($row['meta_field'] ?? $row['sponsorship_level'] ?? ''); ?>
                <tr>
                    <td><?= e((string) ($row['request_type'] ?? '')) ?></td>
                    <td><?= e((string) ($row['display_name'] ?? '')) ?></td>
                    <td><?= e((string) ($row['contact_person'] ?? '')) ?></td>
                    <td><?= e((string) ($row['email'] ?? '')) ?></td>
                    <td><?= e($meta) ?></td>
                    <td><?= e(substr((string) ($row['message'] ?? ''), 0, 180)) ?></td>
                    <td><?= e((string) ($row['created_at'] ?? '')) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($rows)): ?>
                <tr>
                    <td colspan="7">Keine Datensaetze.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>

<?php admin_render_end(); ?>
