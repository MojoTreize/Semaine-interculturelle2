<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';

if (!function_exists('admin_navigation_items')) {
    function admin_navigation_items(): array
    {
        return [
            ['key' => 'dashboard', 'label' => t('admin.dashboard'), 'path' => 'index.php'],
            ['key' => 'events', 'label' => t('admin.menu_program'), 'path' => 'events.php'],
            ['key' => 'registrations', 'label' => t('admin.menu_registrations'), 'path' => 'registrations.php'],
            ['key' => 'requests', 'label' => 'Anfragen', 'path' => 'requests.php'],
            ['key' => 'donations', 'label' => t('admin.menu_donations'), 'path' => 'donations.php'],
        ];
    }
}

if (!function_exists('admin_db_or_fail')) {
    function admin_db_or_fail(mixed $pdo): PDO
    {
        if ($pdo instanceof PDO) {
            return $pdo;
        }

        http_response_code(500);
        echo '<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><title>Admin</title></head><body>';
        echo '<p>Datenbankverbindung nicht verfuegbar. Bitte config/config.php pruefen.</p>';
        echo '</body></html>';
        exit;
    }
}

if (!function_exists('admin_render_start')) {
    function admin_render_start(string $title, string $activeMenu): void
    {
        $flash = get_flash();
        $admin = admin_user();
        $menuItems = admin_navigation_items();
        ?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - Admin</title>
    <link rel="stylesheet" href="<?= e(base_url('assets/css/admin.css')) ?>">
</head>
<body>
<div class="admin-wrap">
    <aside class="admin-sidebar">
        <h1><?= e(t('admin.title')) ?></h1>
        <nav class="admin-menu">
            <?php foreach ($menuItems as $item): ?>
                <?php $isActive = $activeMenu === (string) $item['key']; ?>
                <a class="<?= $isActive ? 'active' : '' ?>" href="<?= e(admin_url((string) $item['path'])) ?>"><?= e((string) $item['label']) ?></a>
            <?php endforeach; ?>
        </nav>
    </aside>

    <main class="admin-main">
        <div class="admin-top">
            <strong><?= e((string) ($admin['full_name'] ?? 'Admin')) ?></strong>
            <a class="btn btn-muted" href="<?= e(admin_url('logout.php')) ?>"><?= e(t('admin.logout')) ?></a>
        </div>

        <?php if ($flash): ?>
            <div class="alert alert-<?= e((string) ($flash['type'] ?? 'success')) ?>">
                <?= e((string) ($flash['message'] ?? '')) ?>
            </div>
        <?php endif; ?>
<?php
    }
}

if (!function_exists('admin_render_end')) {
    function admin_render_end(): void
    {
        ?>
    </main>
</div>
</body>
</html>
<?php
    }
}
